import React from 'react'
import Sidebar from './Sidebar'
import TopNavigation from './components/TopNavigation'
import ContentContainer from './components/ContentContainer'

const App = () => {
  return (
    <div className="flex">
      <Sidebar/>
      <ContentContainer/>
    </div>
  )
}

export default App