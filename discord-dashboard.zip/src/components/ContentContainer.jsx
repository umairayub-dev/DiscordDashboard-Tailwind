import React from 'react'
import TopNavigation from './TopNavigation'

const ContentContainer = () => {
  return (
    <div className='content-container'>
        <TopNavigation/>
    </div>
  )
}

export default ContentContainer